import os
path = "D:/AAA____GMU/Class/2022_Spring/571 OS/ebpf/ebpf_download_folder_test" 
filenames= os.listdir(path) 
code = []
comment = []
files = []
language = {}

for file in filenames: 
    f = open(path+"/"+file) 
    lines = f.readlines()
    t= lines[-2].split(" ") #Row SUM
    while '' in t:
        t.remove('')
    code.append(int(t[-1]))  
    comment.append(int(t[-2]))
    files.append(int(t[-4]))
    
    lang = lines[4].split(" ")[0]                    #Col Language
    if lang in language.keys():
        language[lang] += 1
    else:
        language[lang] = 1
    
    
    
max_code = max(code)
max_code_ind = code.index(max_code)
print(max_code_ind, max_code)
    
    
code2 = [0,0,0,0,0,0] # 0:0-500, 1:500-1000,  2:1001-2000, 3:2000-10000, 4:10000-100000, 5;>100000
code3 = []
for i in code:
    if i<500:
        code2[0] += 1
        code3.append(0)
    elif i<1000:
        code2[1] += 1
        code3.append(1)
    elif i<2000:
        code2[2] += 1
        code3.append(2)
    elif i<10000:  
        code2[3] += 1
        code3.append(3)
    elif i<100000:
        code2[4] += 1
        code3.append(4)
    else:
        code2[5] += 1
        code3.append(5)

comment2 = [0,0,0,0,0,0,0] #0:0-50, 1:50-100, 2:100-200, 3:200-500, 4:500-1000, 5:1000-10000, 6>10000
for i in comment:
    if i < 50:
        comment2[0] += 1
    elif i < 100:
        comment2[1] += 1
    elif i < 200:
        comment2[2] += 1
    elif i < 500:
        comment2[3] += 1
    elif i < 1000:
        comment2[4] += 1
    elif i < 10000:
        comment2[5] += 1
    else:
        comment2[6] += 1
        
files2 = [0,0,0,0,0,0,0] #0: 0-20，  1：20-50， 2：50-100， 3：100-200， 4：200-500， 5：500-1000，6：>1000
for i in files:
    if i < 20:
        files2[0] += 1
    elif i < 50:
        files2[1] += 1
    elif i < 100:
        files2[2] += 1
    elif i < 200:
        files2[3] += 1
    elif i < 500:
        files2[4] += 1
    elif i < 1000:
        files2[5] += 1
    else:
        files2[6] += 1
        
lang2 = [0,0,0,0,0,0,0,0]
for i in language.keys():
    if i == 'C' or i == 'C++' or i == 'C/C++':
        lang2[0] += language[i]
    elif i == 'Python':
        lang2[1] = language[i]
    elif i == 'Go':
        lang2[2] = language[i]
    elif i == 'Rust':
        lang2[3] = language[i]
    elif i == 'Markdown':
        lang2[4] = language[i]
    elif i == 'YAML':
        lang2[5] = language[i]
    elif i == 'JSON':
        lang2[6] = language[i]
    else:
        lang2[7] += language[i]

        
        
        
f2w = open("D:/AAA____GMU/Class/2022_Spring/571 OS/ebpf/result.txt","w")
f2w.write("Code:\n")
for n in code:
    f2w.write(str(n)+",")
f2w.write("\n\n")

f2w.write("Code2:\n")
for n in code2:
    f2w.write(str(n)+",")
f2w.write("\n\n")

f2w.write("Code3:\n")
for n in code3:
    f2w.write(str(n)+",")
f2w.write("\n\n")

f2w.write("comment:\n")
for n in comment:
    f2w.write(str(n)+",")
f2w.write("\n\n")

f2w.write("comment2:\n")
for n in comment2:
    f2w.write(str(n)+",")
f2w.write("\n\n")

f2w.write("files:\n")
for n in files:
    f2w.write(str(n)+",")
f2w.write("\n\n")

f2w.write("files2:\n")
for n in files2:
    f2w.write(str(n)+",")
f2w.write("\n\n")

f2w.write("language:\n")
for n in language.keys():
    f2w.write(str(n)+": "+str(language[n])+",         ")
f2w.write("\n\n")
    
f2w.write("language2:\n")
for n in lang2:
    f2w.write(str(n)+",")
f2w.write("\n\n")

