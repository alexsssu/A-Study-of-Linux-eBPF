import json
import wget
import time
import csv
import requests
import math

DELAY_BETWEEN_QUERIES = 2

def getUrl(url):
    """ Given a URL it returns its body """
    response = requests.get(url)
    return response.json()

def download_git(urls, OUTPUT_FOLDER, OUTPUT_CSV_FILE):
    count = 1
    csv_file = open(OUTPUT_CSV_FILE, 'w')
    repositories = csv.writer(csv_file, delimiter=',')
    for pageUrl in urls:
        data = json.loads(json.dumps(getUrl(pageUrl)))
        for item in data['items']:
            user = item['owner']['login']
            repository = item['name']
            # Download the zip file of the current project
            # print("Downloading repository '%s' from user '%s' ..." % (repository, user))
            url = item['clone_url']
            fileToDownload = url[0:len(url) - 4] + "/archive/refs/heads/master.zip"
            fileName = item['full_name'].replace("/", "#") + ".zip"
            try:
                #print("ready:")
                time.sleep(DELAY_BETWEEN_QUERIES)
                wget.download(fileToDownload, out=OUTPUT_FOLDER + fileName)
                repositories.writerow([user, repository, url, "downloaded"])
                print(" " + str(count) + " Downloaded repository '%s' from user '%s' ..." % (repository, user))
                count += 1
            except Exception as e:
                print("Could not download file {}".format(fileToDownload))
                #print(e)
                repositories.writerow([user, repository, url, "error when downloading"])
        

if __name__ == '__main__':
    urls = list()
    for i in range(1, 11):
        url = "https://api.github.com/search/repositories?q=ebpf&page=" + str(i) + "&per_page=100"
        urls.append(url)
    #print(urls)
    OUTPUT_FOLDER = "ebpf_download_folder/"
    OUTPUT_CSV_FILE = "repositories.csv"
    download_git(urls, OUTPUT_FOLDER, OUTPUT_CSV_FILE)
